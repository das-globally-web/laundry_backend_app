from django.urls import path, include
from .views import get_users, login_user, signup

urlpatterns = [
    path('signup', signup, name='signup'),
    path('users', get_users, name='get_users'),
    path('login', login_user, name='login_user')
]